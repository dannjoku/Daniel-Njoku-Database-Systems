SELECT staff.sid As Cleaner
    avg(rc.timeOfEntry - rc.timeOfExit) AS AVG Cleaning Time
FROM    staff s
        roomCleaning rc
WHERE rc.timeOfExit IS NOT NULL
AND     s.sid = rc.sid;
GROUP BY s.sid;



SELECT g.gid as GuestStay
    avg(gr.checkInDate - gr.checkOutDate)  AS Average Stay
FROM    guestReservation gr,
        guest g,
        rooms r
WHERE   gr.checkOutDate IS NOT NULL
AND     r.roomNumber = gr.roomNumber
GROUP BY g.gid;