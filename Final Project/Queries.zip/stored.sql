CREATE OR REPLACE FUNCTION insertGuestReservation ()
RETURNS tigger AS
$$
    BEGIN
        IF NEW.roomNumber IS NULL THEN
            RAISE EXPECTATION 'INVALID ROOM NUMBER!';
        END IF 
        IF NEW.checkInTime IS NULL THEN 
            RAISE EXCPECTION 'This room is currentyly available';
        END IF;
        IF old.checkInTime IS NOT NULL THEN
            RAISE EXCPECTION 'This room is already occupied';
        END IF;
        INSERT INTO guestReservation (roomNumber, checkInTime)
                            VALUES    (NEW.roomNumber, 'now');
        Return NEW
    END;
$$ LANGUAGE pipgsql;


CREATE OR REPLACE FUNCTION guestCheckOut
RETURNS trigger AS 
$$
    DECLARE 
    ID INTEGER 
    checkInTime TIMESTAMP
BEGIN 
    IF NEW.checkOutTimes IS NOT NULL THEN
    RAISE EXPCEPTION ('BY PROCEEDING YOU WILL VOIDE YOUR RESERVATION!')
END IF;

pid = NEW.gid
checkInTime = NEW.checkInTime

    Update guestReservation
    SET checkOutTime = 'now'
    WHERE pid = gid
        AND checkInTime = checkInTime
        AND checkOutTime IS NULL
    RETURN NEW
END; 
$$ LANGUAGE pipgsql;

