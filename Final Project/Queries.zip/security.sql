GRANT INSERT ON roomCalls TO guests; 

administration

GRANT SELECT ON location TO hospitalAdministrator;
GRANT SELECT, INSERT, UPDATE ON persons TO Administration;
GRANT SELECT, INSERT, UPDATE ON guests TO Administration;
GRANT SELECT, INSERT, UPDATE ON staff TO Administration;
GRANT SELECT, INSERT, UPDATE, DELETE ON staffPosition TO Administration;
GRANT SELECT, INSERT, UPDATE, DELETE ON shifts TO Administration;
GRANT SELECT, INSERT, UPDATE, DELETE ON shiftDays TO Administration;
GRANT SELECT, INSERT, UPDATE ON patientVisits TO Administration;
GRANT SELECT, INSERT, UPDATE ON bedAssignments TO Administration;
GRANT SELECT, UPDATE ON roomCalls TO Administration;
GRANT SELECT, INSERT, UPDATE, DELETE ON callCodes TO Administration;
GRANT SELECT, UPDATE ON roomCleaning TO Administration;
GRANT SELECT, UPDATE ON rooms TO Administration;
GRANT SELECT, UPDATE ON style TO Administration;

GRANT SELECT, UPDATE ON roomCleaning TO houseKeeping;
GRANT SELECT ON rooms TO houseKeeping;
