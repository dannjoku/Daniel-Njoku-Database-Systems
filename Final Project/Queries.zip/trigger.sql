CREATE TRIGGER addRoomToRoomCleaning
AFTER UPDATE ON guestReservation
FOR EACH ROW EXECUTE PROCEDURE  insertRoomCleaning();


